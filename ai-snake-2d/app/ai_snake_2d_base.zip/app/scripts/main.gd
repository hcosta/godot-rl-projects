extends Node2D

const GRID_WIDTH = 16
const GRID_HEIGHT = 16

var food: Vector2i
var score: int = 0
var step_time: float = 0.2
var timer: float = 0.0
var game_over: bool = false

@onready var snake: Snake = $Snake

func _ready() -> void:
	start_game()

func start_game() -> void:
	game_over = false
	score = 0
	timer = 0.0
	snake.reset()
	spawn_food()

func _process(delta: float) -> void:
	if game_over:
		if Input.is_action_just_pressed("ui_accept"):
			start_game()
		return

	timer += delta
	if timer >= step_time:
		timer = 0.0
		process_turn()

func process_turn() -> void:
	var future_head = snake.advance_step()
	
	if future_head.x < 0 or future_head.x >= GRID_WIDTH or future_head.y < 0 or future_head.y >= GRID_HEIGHT:
		end_game()
		return
		
	if snake.check_self_collision(future_head):
		end_game()
		return
		
	if future_head == food:
		snake.extend_to(future_head)
		score += 1
		spawn_food()
	else:
		snake.move_to(future_head)

func spawn_food() -> void:
	randomize()
	while true:
		var pos = Vector2i(randi() % GRID_WIDTH, randi() % GRID_HEIGHT)
		if not pos in snake.body:
			food = pos
			# Le pasamos la nueva coordenada a la serpiente para que la dibuje
			snake.update_food(food) 
			break

func end_game() -> void:
	game_over = true
	print("Game Over! Score: ", score)
